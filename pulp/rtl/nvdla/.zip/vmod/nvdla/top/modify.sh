#echo -e "\`define VLIB_BYPASS_POWER_CG\n\`define NV_FPGA_FIFOGEN\n\`define FIFOGEN_MASTER_CLK_GATING_DISABLED\n\`define FPGA\n\`define SYNTHESIS\n" >> test.v

#sed -i '1i\`define VLIB_BYPASS_POWER_CG\n`define NV_FPGA_FIFOGEN\n`define FIFOGEN_MASTER_CLK_GATING_DISABLED\n`define FPGA\n`define SYNTHESIS\n' test.v

#! /bin/bash
#$PATH = /home/zyx/vivadoworkspace/ip_nvsmall64_projcet/ip_nvsmall64_projcet.srcs/sources_1/imports/vmod
PATH = /home/zyx/test

for file in $(PATH);
do
 sed -i '1i\`define VLIB_BYPASS_POWER_CG\n`define NV_FPGA_FIFOGEN\n`define FIFOGEN_MASTER_CLK_GATING_DISABLED\n`define FPGA\n`define SYNTHESIS\n' $$file
done


